use crate::accessibility::to_wide;
use crate::i18n;
use crate::settings::Language;
use crate::with_state;
use windows::Win32::Foundation::HWND;
use windows::Win32::UI::WindowsAndMessaging::{MB_ICONINFORMATION, MB_OK};
use windows::core::PCWSTR;

pub fn show(hwnd: HWND) {
    let language = { with_state(hwnd, |state| state.settings.language) }.unwrap_or_default();
    let message = to_wide(&about_message(language));
    let title = to_wide(&about_title(language));
    crate::show_blocking_modal_message_box(
        hwnd,
        crate::BlockingModalKind::InfoDialog,
        PCWSTR(message.as_ptr()),
        PCWSTR(title.as_ptr()),
        MB_OK | MB_ICONINFORMATION,
    );
}

fn about_title(language: Language) -> String {
    i18n::tr(language, "about.title")
}

fn about_message(language: Language) -> String {
    let version = crate::app_display_version();
    i18n::tr_f(language, "about.message", &[("version", version)])
}
