use crate::accessibility::{EM_REPLACESEL, EM_SCROLLCARET, to_wide};
use crate::app_windows::podcast_save_window::{
    self, SaveDialogLabels, WM_PODCAST_SAVE_DONE, WM_PODCAST_SAVE_PROGRESS,
};
use crate::editor_manager::get_edit_text;
use crate::i18n;
use crate::settings::{Language, find_title, text_not_found_message};
use crate::{get_active_edit, show_error, show_info, with_state};
use fancy_regex::Regex;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use windows::Win32::Foundation::HINSTANCE;
use windows::Win32::Foundation::{BOOL, HWND, LPARAM, WPARAM};
use windows::Win32::Graphics::Gdi::DEFAULT_GUI_FONT;
use windows::Win32::Graphics::Gdi::InvalidateRect;
use windows::Win32::UI::Controls::Dialogs::{
    FINDREPLACE_FLAGS, FINDREPLACEW, FR_DIALOGTERM, FR_DOWN, FR_ENABLEHOOK, FR_FINDNEXT,
    FR_HIDEMATCHCASE, FR_HIDEWHOLEWORD, FR_MATCHCASE, FR_REPLACE, FR_REPLACEALL, FR_WHOLEWORD,
    FindTextW, ReplaceTextW,
};
use windows::Win32::UI::Controls::RichEdit::{
    CHARRANGE, EM_EXGETSEL, EM_EXSETSEL, EM_FINDTEXTEXW, FINDTEXTEXW,
};
use windows::Win32::UI::Controls::{BST_CHECKED, WC_BUTTON};
use windows::Win32::UI::Input::KeyboardAndMouse::SetFocus;
use windows::Win32::UI::WindowsAndMessaging::{
    BM_GETCHECK, BM_SETCHECK, BS_AUTOCHECKBOX, CreateWindowExW, GetClientRect, GetWindowRect,
    HMENU, MB_ICONWARNING, MB_OK, SWP_NOMOVE, SWP_NOZORDER, SendMessageW, SetWindowPos,
    WINDOW_STYLE, WM_APP, WM_COMMAND, WM_GETTEXTLENGTH, WM_INITDIALOG, WM_SETFONT, WM_SETREDRAW,
};
use windows::core::{PCWSTR, PWSTR};

pub const FIND_DIALOG_ID: isize = 1;
pub const REPLACE_DIALOG_ID: isize = 2;
pub const WM_REPLACE_ALL_DONE: u32 = WM_APP + 191;
pub const WM_REPLACE_ALL_PROGRESS: u32 = WM_APP + 192;
const FIND_ID_REGEX: isize = 5101;
const FIND_ID_DOT_MATCHES_NEWLINE: isize = 5102;
const FIND_ID_WRAP_AROUND: isize = 5103;
const FIND_ID_MATCH_CASE: isize = 5106;
const FIND_ID_WHOLE_WORD: isize = 5107;
const REPLACE_ID_IN_SELECTION: isize = 5104;
const REPLACE_ID_IN_ALL_DOCS: isize = 5105;
struct ReplaceAllDone {
    progress: HWND,
    language: Language,
    count: usize,
    canceled: bool,
    patches: Vec<ReplacePatch>,
}

struct ReplacePatch {
    hwnd_edit: HWND,
    start_utf16: i32,
    end_utf16: i32,
    replaced: String,
}

#[derive(Copy, Clone)]
pub struct FindOptions {
    pub use_regex: bool,
    pub dot_matches_newline: bool,
    pub wrap_around: bool,
    pub match_case: bool,
    pub whole_word: bool,
    pub replace_in_selection: bool,
    pub replace_in_all_docs: bool,
}

pub fn open_find_dialog(hwnd: HWND) {
    unsafe {
        let has_dialog = with_state(hwnd, |state| state.find_dialog.0 != 0).unwrap_or(false);
        if has_dialog {
            with_state(hwnd, |state| {
                SetFocus(state.find_dialog);
            });
            return;
        }

        with_state(hwnd, |state| {
            state.find_replace = Some(FINDREPLACEW {
                lStructSize: std::mem::size_of::<FINDREPLACEW>() as u32,
                hwndOwner: hwnd,
                Flags: FR_DOWN | FR_ENABLEHOOK | FR_HIDEMATCHCASE | FR_HIDEWHOLEWORD,
                lpstrFindWhat: PWSTR(state.find_text.as_mut_ptr()),
                wFindWhatLen: state.find_text.len() as u16,
                lCustData: LPARAM(FIND_DIALOG_ID),
                lpfnHook: Some(find_replace_hook_proc),
                ..Default::default()
            });

            if let Some(ref mut fr) = state.find_replace {
                let dialog = FindTextW(fr);
                state.find_dialog = dialog;
            }
        });
    }
}

pub fn open_replace_dialog(hwnd: HWND) {
    unsafe {
        let has_dialog = with_state(hwnd, |state| state.replace_dialog.0 != 0).unwrap_or(false);
        if has_dialog {
            with_state(hwnd, |state| {
                SetFocus(state.replace_dialog);
            });
            return;
        }

        with_state(hwnd, |state| {
            state.replace_replace = Some(FINDREPLACEW {
                lStructSize: std::mem::size_of::<FINDREPLACEW>() as u32,
                hwndOwner: hwnd,
                Flags: FR_DOWN | FR_ENABLEHOOK | FR_HIDEMATCHCASE | FR_HIDEWHOLEWORD,
                lpstrFindWhat: PWSTR(state.find_text.as_mut_ptr()),
                wFindWhatLen: state.find_text.len() as u16,
                lpstrReplaceWith: PWSTR(state.replace_text.as_mut_ptr()),
                wReplaceWithLen: state.replace_text.len() as u16,
                lCustData: LPARAM(REPLACE_DIALOG_ID),
                lpfnHook: Some(find_replace_hook_proc),
                ..Default::default()
            });

            if let Some(ref mut fr) = state.replace_replace {
                let dialog = ReplaceTextW(fr);
                state.replace_dialog = dialog;
            }
        });
    }
}

pub fn handle_find_message(hwnd: HWND, lparam: LPARAM) {
    unsafe {
        let fr = &*(lparam.0 as *const FINDREPLACEW);
        if (fr.Flags & FR_DIALOGTERM) != FINDREPLACE_FLAGS(0) {
            with_state(hwnd, |state| {
                if fr.lCustData.0 == FIND_DIALOG_ID {
                    state.find_dialog = HWND(0);
                    state.find_replace = None;
                } else if fr.lCustData.0 == REPLACE_DIALOG_ID {
                    state.replace_dialog = HWND(0);
                    state.replace_replace = None;
                }
            });
            return;
        }

        if (fr.Flags & (FR_FINDNEXT | FR_REPLACE | FR_REPLACEALL)) == FINDREPLACE_FLAGS(0) {
            return;
        }

        let search = {
            let buf_len = fr.wFindWhatLen as usize;
            let slice = std::slice::from_raw_parts(fr.lpstrFindWhat.0, buf_len);
            let len = slice.iter().position(|&c| c == 0).unwrap_or(buf_len);
            String::from_utf16_lossy(&slice[..len])
        };
        if search.is_empty() {
            return;
        }

        let Some(hwnd_edit) = get_active_edit(hwnd) else {
            return;
        };
        let language = with_state(hwnd, |state| state.settings.language).unwrap_or_default();

        let options = get_find_options(hwnd);
        let find_flags = extract_find_flags(fr.Flags, &options);
        with_state(hwnd, |state| {
            state.last_find_flags = find_flags;
        });

        if (fr.Flags & FR_REPLACEALL) != FINDREPLACE_FLAGS(0) {
            replace_all(
                hwnd,
                hwnd_edit,
                &search,
                &{
                    let buf_len = fr.wReplaceWithLen as usize;
                    let slice = std::slice::from_raw_parts(fr.lpstrReplaceWith.0, buf_len);
                    let len = slice.iter().position(|&c| c == 0).unwrap_or(buf_len);
                    String::from_utf16_lossy(&slice[..len])
                },
                find_flags,
                &options,
            );
            return;
        }

        if (fr.Flags & FR_REPLACE) != FINDREPLACE_FLAGS(0) {
            let replace = {
                let buf_len = fr.wReplaceWithLen as usize;
                let slice = std::slice::from_raw_parts(fr.lpstrReplaceWith.0, buf_len);
                let len = slice.iter().position(|&c| c == 0).unwrap_or(buf_len);
                String::from_utf16_lossy(&slice[..len])
            };
            let replaced = replace_selection_if_match(
                hwnd, hwnd_edit, &search, &replace, find_flags, &options,
            );
            let found = find_next(
                hwnd,
                hwnd_edit,
                &search,
                find_flags,
                options.wrap_around,
                &options,
            );
            if !replaced && !found {
                let message = to_wide(&text_not_found_message(language));
                let title = to_wide(&find_title(language));
                crate::message_box_modal(
                    hwnd,
                    PCWSTR(message.as_ptr()),
                    PCWSTR(title.as_ptr()),
                    MB_OK | MB_ICONWARNING,
                );
            }
            return;
        }

        if find_next(
            hwnd,
            hwnd_edit,
            &search,
            find_flags,
            options.wrap_around,
            &options,
        ) {
            return;
        }
        let message = to_wide(&text_not_found_message(language));
        let title = to_wide(&find_title(language));
        crate::message_box_modal(
            hwnd,
            PCWSTR(message.as_ptr()),
            PCWSTR(title.as_ptr()),
            MB_OK | MB_ICONWARNING,
        );
    }
}

pub fn find_next_from_state(hwnd: HWND) {
    {
        let (search, flags, language): (String, FINDREPLACE_FLAGS, Language) =
            with_state(hwnd, |state| {
                let len = state
                    .find_text
                    .iter()
                    .position(|&c| c == 0)
                    .unwrap_or(state.find_text.len());
                let search = String::from_utf16_lossy(&state.find_text[..len]);
                (search, state.last_find_flags, state.settings.language)
            })
            .unwrap_or((String::new(), FINDREPLACE_FLAGS(0), Language::default()));
        if search.is_empty() {
            open_find_dialog(hwnd);
            return;
        }
        let Some(hwnd_edit) = get_active_edit(hwnd) else {
            return;
        };
        let options = get_find_options(hwnd);
        if !find_next(
            hwnd,
            hwnd_edit,
            &search,
            flags,
            options.wrap_around,
            &options,
        ) {
            let message = to_wide(&text_not_found_message(language));
            let title = to_wide(&find_title(language));
            crate::message_box_modal(
                hwnd,
                PCWSTR(message.as_ptr()),
                PCWSTR(title.as_ptr()),
                MB_OK | MB_ICONWARNING,
            );
        }
    }
}

pub fn find_previous_from_state(hwnd: HWND) {
    {
        let (search, mut flags, language): (String, FINDREPLACE_FLAGS, Language) =
            with_state(hwnd, |state| {
                let len = state
                    .find_text
                    .iter()
                    .position(|&c| c == 0)
                    .unwrap_or(state.find_text.len());
                let search = String::from_utf16_lossy(&state.find_text[..len]);
                (search, state.last_find_flags, state.settings.language)
            })
            .unwrap_or((String::new(), FINDREPLACE_FLAGS(0), Language::default()));
        if search.is_empty() {
            open_find_dialog(hwnd);
            return;
        }
        let Some(hwnd_edit) = get_active_edit(hwnd) else {
            return;
        };
        flags &= !FR_DOWN;
        let options = get_find_options(hwnd);
        if !find_next(
            hwnd,
            hwnd_edit,
            &search,
            flags,
            options.wrap_around,
            &options,
        ) {
            let message = to_wide(&text_not_found_message(language));
            let title = to_wide(&find_title(language));
            crate::message_box_modal(
                hwnd,
                PCWSTR(message.as_ptr()),
                PCWSTR(title.as_ptr()),
                MB_OK | MB_ICONWARNING,
            );
        }
    }
}

fn extract_find_flags(flags: FINDREPLACE_FLAGS, options: &FindOptions) -> FINDREPLACE_FLAGS {
    let mut out = FINDREPLACE_FLAGS(0);
    if options.match_case {
        out |= FR_MATCHCASE;
    }
    if options.whole_word {
        out |= FR_WHOLEWORD;
    }
    if (flags & FR_DOWN) != FINDREPLACE_FLAGS(0) {
        out |= FR_DOWN;
    }
    out
}

fn replaced_count_message(language: Language, count: usize) -> String {
    let key = if count == 1 {
        "find.replaced_count_one"
    } else {
        "find.replaced_count_many"
    };
    i18n::tr_f(language, key, &[("count", &count.to_string())])
}

fn suspend_edit_redraw(hwnd_edit: HWND) {
    unsafe {
        SendMessageW(hwnd_edit, WM_SETREDRAW, WPARAM(0), LPARAM(0));
    }
}

fn resume_edit_redraw(hwnd_edit: HWND) {
    unsafe {
        SendMessageW(hwnd_edit, WM_SETREDRAW, WPARAM(1), LPARAM(0));
        if !InvalidateRect(hwnd_edit, None, BOOL(1)).as_bool() {
            crate::log_debug("InvalidateRect failed after replace all");
        }
    }
}

fn open_replace_progress_window(parent: HWND, language: Language) -> HWND {
    let replace_raw = i18n::tr(language, "edit.replace");
    let replace_title = replace_raw
        .split('\t')
        .next()
        .unwrap_or("")
        .replace('&', "")
        .replace("...", "")
        .trim()
        .to_string();
    let labels = SaveDialogLabels {
        title: if replace_title.is_empty() {
            i18n::tr(language, "app.find_title")
        } else {
            replace_title
        },
        in_progress: i18n::tr(language, "podcast.save.in_progress"),
        cancel: i18n::tr(language, "podcast.save.cancel"),
        cancel_confirm: i18n::tr(language, "podcast.cancel_confirm"),
    };
    let dialog = podcast_save_window::open_with_labels(parent, language, labels, true);
    with_state(parent, |state| {
        state.replace_progress_window = dialog;
        state.replace_cancel_requested = false;
    });
    if dialog.0 != 0 {
        crate::set_foreground_window_safe(dialog);
        crate::app_windows::podcast_save_window::focus_cancel_button(dialog);
        let _unused = crate::post_message_w_safe(
            dialog,
            windows::Win32::UI::WindowsAndMessaging::WM_SETFOCUS,
            WPARAM(0),
            LPARAM(0),
        );
        let _unused = crate::post_message_w_safe(dialog, crate::WM_NULL, WPARAM(0), LPARAM(0));
        crate::app_windows::podcast_save_window::focus_cancel_button(dialog);
    }
    dialog
}

fn close_replace_progress_window(parent: HWND, dialog: HWND) {
    if dialog.0 != 0 {
        crate::send_message_w_safe(dialog, WM_PODCAST_SAVE_DONE, WPARAM(0), LPARAM(0));
    }
    with_state(parent, |state| {
        state.replace_progress_window = HWND(0);
        state.replace_cancel_requested = false;
    });
}

fn update_replace_progress_window(parent: HWND, pct: usize) {
    let dialog = with_state(parent, |state| state.replace_progress_window).unwrap_or(HWND(0));
    if dialog.0 != 0 {
        let _unused = crate::post_message_w_safe(
            dialog,
            WM_PODCAST_SAVE_PROGRESS,
            WPARAM(pct.min(100)),
            LPARAM(0),
        );
    }
}

pub fn find_next(
    hwnd: HWND,
    hwnd_edit: HWND,
    search: &str,
    flags: FINDREPLACE_FLAGS,
    wrap: bool,
    options: &FindOptions,
) -> bool {
    unsafe {
        if options.use_regex {
            return find_next_regex(hwnd, hwnd_edit, search, flags, wrap, options);
        }
        let mut cr = CHARRANGE { cpMin: 0, cpMax: 0 };
        SendMessageW(
            hwnd_edit,
            EM_EXGETSEL,
            WPARAM(0),
            LPARAM(&mut cr as *mut _ as isize),
        );

        let down = (flags & FR_DOWN) != FINDREPLACE_FLAGS(0);
        let wide_search = to_wide(search);

        let mut ft = FINDTEXTEXW {
            chrg: CHARRANGE {
                cpMin: if down { cr.cpMax } else { cr.cpMin },
                cpMax: if down { -1 } else { 0 },
            },
            lpstrText: PCWSTR(wide_search.as_ptr()),
            chrgText: CHARRANGE { cpMin: 0, cpMax: 0 },
        };

        let result = SendMessageW(
            hwnd_edit,
            EM_FINDTEXTEXW,
            WPARAM(flags.0 as usize),
            LPARAM(&mut ft as *mut _ as isize),
        );

        if result.0 != -1 {
            let mut sel = ft.chrgText;
            std::mem::swap(&mut sel.cpMin, &mut sel.cpMax);
            SendMessageW(
                hwnd_edit,
                EM_EXSETSEL,
                WPARAM(0),
                LPARAM(&mut sel as *mut _ as isize),
            );
            SendMessageW(hwnd_edit, EM_SCROLLCARET, WPARAM(0), LPARAM(0));
            SetFocus(hwnd_edit);
            return true;
        }

        if wrap {
            let text_len = SendMessageW(hwnd_edit, WM_GETTEXTLENGTH, WPARAM(0), LPARAM(0)).0 as i32;
            ft.chrg.cpMin = if down { 0 } else { text_len };
            ft.chrg.cpMax = if down { -1 } else { 0 };
            let result = SendMessageW(
                hwnd_edit,
                EM_FINDTEXTEXW,
                WPARAM(flags.0 as usize),
                LPARAM(&mut ft as *mut _ as isize),
            );
            if result.0 != -1 {
                let mut sel = ft.chrgText;
                std::mem::swap(&mut sel.cpMin, &mut sel.cpMax);
                SendMessageW(
                    hwnd_edit,
                    EM_EXSETSEL,
                    WPARAM(0),
                    LPARAM(&mut sel as *mut _ as isize),
                );
                SendMessageW(hwnd_edit, EM_SCROLLCARET, WPARAM(0), LPARAM(0));
                SetFocus(hwnd_edit);
                return true;
            }
        }
        false
    }
}

fn replace_selection_if_match(
    hwnd: HWND,
    hwnd_edit: HWND,
    search: &str,
    replace: &str,
    flags: FINDREPLACE_FLAGS,
    options: &FindOptions,
) -> bool {
    if options.use_regex {
        return replace_selection_if_match_regex(hwnd, hwnd_edit, search, replace, flags, options);
    }
    let mut cr = CHARRANGE { cpMin: 0, cpMax: 0 };
    unsafe {
        SendMessageW(
            hwnd_edit,
            EM_EXGETSEL,
            WPARAM(0),
            LPARAM(&mut cr as *mut _ as isize),
        );
    }

    if cr.cpMin == cr.cpMax {
        return false;
    }

    let wide_search = to_wide(search);
    let mut ft = FINDTEXTEXW {
        chrg: cr,
        lpstrText: PCWSTR(wide_search.as_ptr()),
        chrgText: CHARRANGE { cpMin: 0, cpMax: 0 },
    };

    let res = crate::send_message_w_safe(
        hwnd_edit,
        EM_FINDTEXTEXW,
        WPARAM(flags.0 as usize),
        LPARAM(&mut ft as *mut _ as isize),
    );

    if res.0 == cr.cpMin as isize && ft.chrgText.cpMax == cr.cpMax {
        let replace_wide = to_wide(replace);
        unsafe {
            SendMessageW(
                hwnd_edit,
                EM_REPLACESEL,
                WPARAM(1),
                LPARAM(replace_wide.as_ptr() as isize),
            );
        }
        true
    } else {
        false
    }
}

pub fn replace_all(
    hwnd: HWND,
    hwnd_edit: HWND,
    search: &str,
    replace: &str,
    flags: FINDREPLACE_FLAGS,
    options: &FindOptions,
) {
    if options.use_regex {
        replace_all_regex(hwnd, hwnd_edit, search, replace, flags, options);
        return;
    }
    if search.is_empty() {
        return;
    }
    let language = with_state(hwnd, |state| state.settings.language).unwrap_or_default();
    let replace_dialog = with_state(hwnd, |state| state.replace_dialog).unwrap_or(HWND(0));
    if replace_dialog.0 != 0 {
        crate::send_message_w_safe(
            replace_dialog,
            windows::Win32::UI::WindowsAndMessaging::WM_CLOSE,
            WPARAM(0),
            LPARAM(0),
        );
        with_state(hwnd, |state| {
            state.replace_dialog = HWND(0);
            state.replace_replace = None;
        });
    }
    let progress = open_replace_progress_window(hwnd, language);
    update_replace_progress_window(hwnd, 0);
    let search_owned = search.to_string();
    let replace_owned = replace.to_string();
    let replace_in_all_docs = options.replace_in_all_docs;
    let replace_in_selection = options.replace_in_selection;
    let mut jobs: Vec<(HWND, String, i32, i32)> = Vec::new();
    if replace_in_all_docs {
        let edits = with_state(hwnd, |state| {
            state
                .docs
                .iter()
                .map(|doc| (doc.hwnd_edit, get_edit_text(doc.hwnd_edit)))
                .collect::<Vec<_>>()
        })
        .unwrap_or_default();
        for (hwnd_doc, text) in edits {
            let total_utf16 = byte_index_to_utf16(&text, text.len());
            jobs.push((hwnd_doc, text, 0, total_utf16));
        }
    } else if replace_in_selection {
        let mut cr = CHARRANGE { cpMin: 0, cpMax: 0 };
        unsafe {
            SendMessageW(
                hwnd_edit,
                EM_EXGETSEL,
                WPARAM(0),
                LPARAM(&mut cr as *mut _ as isize),
            );
        }
        if cr.cpMin != cr.cpMax {
            jobs.push((hwnd_edit, get_edit_text(hwnd_edit), cr.cpMin, cr.cpMax));
        }
    } else {
        let text = get_edit_text(hwnd_edit);
        let total_utf16 = byte_index_to_utf16(&text, text.len());
        jobs.push((hwnd_edit, text, 0, total_utf16));
    }
    let total_utf16_all: i32 = jobs.iter().map(|(_, _, s, e)| (e - s).max(0)).sum();
    let cancel_token = Arc::new(AtomicBool::new(false));
    with_state(hwnd, |state| {
        state.replace_cancel_token = Some(cancel_token.clone());
        state.replace_cancel_requested = false;
    });
    std::thread::spawn(move || {
        let mut patches = Vec::new();
        let mut total_count = 0usize;
        let mut processed_utf16 = 0i32;
        let mut last_pct = 0usize;
        for (hwnd_doc, text, start_utf16, end_utf16) in jobs {
            if cancel_token.load(Ordering::Relaxed) {
                break;
            }
            let (count, patch) = compute_replace_patch(
                &text,
                &search_owned,
                &replace_owned,
                flags,
                start_utf16,
                end_utf16,
            );
            if count > 0
                && let Some((patch_start, patch_end, replaced)) = patch
            {
                patches.push(ReplacePatch {
                    hwnd_edit: hwnd_doc,
                    start_utf16: patch_start,
                    end_utf16: patch_end,
                    replaced,
                });
            }
            total_count += count;
            processed_utf16 += (end_utf16 - start_utf16).max(0);
            if total_utf16_all > 0 {
                let pct = ((processed_utf16 as i64 * 100) / total_utf16_all as i64) as usize;
                if pct > last_pct {
                    last_pct = pct;
                    let _unused = crate::post_message_w_safe(
                        hwnd,
                        WM_REPLACE_ALL_PROGRESS,
                        WPARAM(pct),
                        LPARAM(0),
                    );
                }
            }
        }
        let canceled = cancel_token.load(Ordering::Relaxed);
        let done = Box::new(ReplaceAllDone {
            progress,
            language,
            count: total_count,
            canceled,
            patches,
        });
        let _unused = crate::post_message_w_safe(
            hwnd,
            WM_REPLACE_ALL_DONE,
            WPARAM(0),
            LPARAM(Box::into_raw(done) as isize),
        );
    });
}

fn get_find_options(hwnd: HWND) -> FindOptions {
    {
        with_state(hwnd, |state| FindOptions {
            use_regex: state.find_use_regex,
            dot_matches_newline: state.find_dot_matches_newline,
            wrap_around: state.find_wrap_around,
            match_case: state.find_match_case,
            whole_word: state.find_whole_word,
            replace_in_selection: state.find_replace_in_selection,
            replace_in_all_docs: state.find_replace_in_all_docs,
        })
    }
    .unwrap_or(FindOptions {
        use_regex: false,
        dot_matches_newline: false,
        wrap_around: true,
        match_case: false,
        whole_word: false,
        replace_in_selection: false,
        replace_in_all_docs: false,
    })
}

unsafe extern "system" fn find_replace_hook_proc(
    hdlg: HWND,
    msg: u32,
    wparam: WPARAM,
    lparam: LPARAM,
) -> usize {
    crate::panic_guard::guard(
        "find_replace_hook_proc",
        || 0,
        || find_replace_hook_proc_inner(hdlg, msg, wparam, lparam),
    )
}

fn find_replace_hook_proc_inner(hdlg: HWND, msg: u32, wparam: WPARAM, lparam: LPARAM) -> usize {
    match msg {
        WM_INITDIALOG => {
            let fr_ptr = lparam.0 as *mut FINDREPLACEW;
            let Some((parent, is_replace)) = crate::with_raw_mut_ptr_safe(fr_ptr, |fr| {
                (fr.hwndOwner, fr.lCustData.0 == REPLACE_DIALOG_ID)
            }) else {
                return 0;
            };
            let language =
                { with_state(parent, |state| state.settings.language) }.unwrap_or_default();
            let (width, height, client_bottom) = dialog_metrics(hdlg);

            let (
                regex_text,
                dot_text,
                wrap_text,
                case_text,
                word_text,
                selection_text,
                all_docs_text,
            ) = (
                i18n::tr(language, "find.regex"),
                i18n::tr(language, "find.dot_matches_newline"),
                i18n::tr(language, "find.wrap_around"),
                i18n::tr(language, "find.match_case"),
                i18n::tr(language, "find.whole_word"),
                i18n::tr(language, "find.replace_in_selection"),
                i18n::tr(language, "find.replace_in_all_docs"),
            );
            let options = get_find_options(parent);

            let mut y = client_bottom + 8;
            let line_h = 18;
            let gap = 4;
            let mut added = 5; // Regex, Dot, Wrap, Case, Word
            if is_replace {
                added += 2; // In selection, All docs
            }
            let extra = (added * (line_h + gap)) + 10;
            crate::log_if_err!(unsafe {
                SetWindowPos(
                    hdlg,
                    HWND(0),
                    0,
                    0,
                    width,
                    height + extra,
                    SWP_NOMOVE | SWP_NOZORDER,
                )
            });

            let x = 12;
            let checkbox_width = width.saturating_sub(x + 16);
            let font = crate::get_stock_object_safe(DEFAULT_GUI_FONT);

            let regex = create_checkbox(hdlg, FIND_ID_REGEX, &regex_text, x, y, checkbox_width);
            set_checkbox_checked(regex, options.use_regex);
            y += line_h + gap;

            let dot = create_checkbox(
                hdlg,
                FIND_ID_DOT_MATCHES_NEWLINE,
                &dot_text,
                x,
                y,
                checkbox_width,
            );
            set_checkbox_checked(dot, options.dot_matches_newline);
            y += line_h + gap;

            let wrap = create_checkbox(hdlg, FIND_ID_WRAP_AROUND, &wrap_text, x, y, checkbox_width);
            set_checkbox_checked(wrap, options.wrap_around);
            y += line_h + gap;

            let case_cb =
                create_checkbox(hdlg, FIND_ID_MATCH_CASE, &case_text, x, y, checkbox_width);
            set_checkbox_checked(case_cb, options.match_case);
            y += line_h + gap;

            let word_cb =
                create_checkbox(hdlg, FIND_ID_WHOLE_WORD, &word_text, x, y, checkbox_width);
            set_checkbox_checked(word_cb, options.whole_word);
            y += line_h + gap;

            if is_replace {
                let sel = create_checkbox(
                    hdlg,
                    REPLACE_ID_IN_SELECTION,
                    &selection_text,
                    x,
                    y,
                    checkbox_width,
                );
                set_checkbox_checked(sel, options.replace_in_selection);
                y += line_h + gap;

                let all_docs = create_checkbox(
                    hdlg,
                    REPLACE_ID_IN_ALL_DOCS,
                    &all_docs_text,
                    x,
                    y,
                    checkbox_width,
                );
                set_checkbox_checked(all_docs, options.replace_in_all_docs);
            }

            if font.0 != 0 {
                for id in [
                    FIND_ID_REGEX,
                    FIND_ID_DOT_MATCHES_NEWLINE,
                    FIND_ID_WRAP_AROUND,
                    FIND_ID_MATCH_CASE,
                    FIND_ID_WHOLE_WORD,
                    REPLACE_ID_IN_SELECTION,
                    REPLACE_ID_IN_ALL_DOCS,
                ] {
                    let hwnd_child = crate::get_dlg_item_safe(hdlg, id as i32);
                    if hwnd_child.0 != 0 {
                        unsafe {
                            SendMessageW(
                                hwnd_child,
                                WM_SETFONT,
                                WPARAM(font.0 as usize),
                                LPARAM(1),
                            );
                        }
                    }
                }
            }
            1
        }
        WM_COMMAND => {
            let cmd_id = (wparam.0 & 0xffff) as isize;
            let parent = crate::get_parent_safe(hdlg);
            if parent.0 == 0 {
                return 0;
            }
            match cmd_id {
                FIND_ID_REGEX => {
                    let checked = is_checkbox_checked(hdlg, FIND_ID_REGEX);
                    {
                        with_state(parent, |state| {
                            state.find_use_regex = checked;
                        });
                    }
                }
                FIND_ID_DOT_MATCHES_NEWLINE => {
                    let checked = is_checkbox_checked(hdlg, FIND_ID_DOT_MATCHES_NEWLINE);
                    {
                        with_state(parent, |state| {
                            state.find_dot_matches_newline = checked;
                        });
                    }
                }
                FIND_ID_WRAP_AROUND => {
                    let checked = is_checkbox_checked(hdlg, FIND_ID_WRAP_AROUND);
                    {
                        with_state(parent, |state| {
                            state.find_wrap_around = checked;
                        });
                    }
                }
                FIND_ID_MATCH_CASE => {
                    let checked = is_checkbox_checked(hdlg, FIND_ID_MATCH_CASE);
                    {
                        with_state(parent, |state| {
                            state.find_match_case = checked;
                        });
                    }
                }
                FIND_ID_WHOLE_WORD => {
                    let checked = is_checkbox_checked(hdlg, FIND_ID_WHOLE_WORD);
                    {
                        with_state(parent, |state| {
                            state.find_whole_word = checked;
                        });
                    }
                }
                REPLACE_ID_IN_SELECTION => {
                    let checked = is_checkbox_checked(hdlg, REPLACE_ID_IN_SELECTION);
                    {
                        with_state(parent, |state| {
                            state.find_replace_in_selection = checked;
                            if checked {
                                state.find_replace_in_all_docs = false;
                            }
                        });
                    }
                    if checked {
                        set_checkbox_checked_by_id(hdlg, REPLACE_ID_IN_ALL_DOCS, false);
                    }
                }
                REPLACE_ID_IN_ALL_DOCS => {
                    let checked = is_checkbox_checked(hdlg, REPLACE_ID_IN_ALL_DOCS);
                    {
                        with_state(parent, |state| {
                            state.find_replace_in_all_docs = checked;
                            if checked {
                                state.find_replace_in_selection = false;
                            }
                        });
                    }
                    if checked {
                        set_checkbox_checked_by_id(hdlg, REPLACE_ID_IN_SELECTION, false);
                    }
                }
                _ => {}
            }
            0
        }
        _ => 0,
    }
}

fn dialog_metrics(hwnd: HWND) -> (i32, i32, i32) {
    unsafe {
        let mut rc_client = windows::Win32::Foundation::RECT::default();
        let mut rc_window = windows::Win32::Foundation::RECT::default();
        crate::log_if_err!(GetClientRect(hwnd, &mut rc_client));
        crate::log_if_err!(GetWindowRect(hwnd, &mut rc_window));
        let width = rc_window.right - rc_window.left;
        let height = rc_window.bottom - rc_window.top;
        (width, height, rc_client.bottom)
    }
}

fn create_checkbox(parent: HWND, id: isize, text: &str, x: i32, y: i32, width: i32) -> HWND {
    let wide = to_wide(text);
    unsafe {
        CreateWindowExW(
            Default::default(),
            WC_BUTTON,
            PCWSTR(wide.as_ptr()),
            windows::Win32::UI::WindowsAndMessaging::WS_CHILD
                | windows::Win32::UI::WindowsAndMessaging::WS_VISIBLE
                | windows::Win32::UI::WindowsAndMessaging::WS_TABSTOP
                | WINDOW_STYLE(BS_AUTOCHECKBOX as u32),
            x,
            y,
            width,
            18,
            parent,
            HMENU(id),
            HINSTANCE(0),
            None,
        )
    }
}

fn is_checkbox_checked(hwnd: HWND, id: isize) -> bool {
    let hwnd_child = crate::get_dlg_item_safe(hwnd, id as i32);
    if hwnd_child.0 == 0 {
        return false;
    }
    let res = crate::send_message_w_safe(hwnd_child, BM_GETCHECK, WPARAM(0), LPARAM(0));
    res.0 as u32 == BST_CHECKED.0
}

fn set_checkbox_checked(hwnd: HWND, checked: bool) {
    if hwnd.0 == 0 {
        return;
    }
    let value = if checked {
        BST_CHECKED
    } else {
        Default::default()
    };
    crate::send_message_w_safe(hwnd, BM_SETCHECK, WPARAM(value.0 as usize), LPARAM(0));
}

fn set_checkbox_checked_by_id(hwnd: HWND, id: isize, checked: bool) {
    let hwnd_child = crate::get_dlg_item_safe(hwnd, id as i32);
    set_checkbox_checked(hwnd_child, checked);
}

fn normalize_regex_replacement(replace: &str) -> String {
    let mut out = String::with_capacity(replace.len());
    let mut chars = replace.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '\\'
            && let Some(next) = chars.peek()
            && next.is_ascii_digit()
        {
            out.push('$');
            out.push(*next);
            chars.next();
            continue;
        }
        out.push(ch);
    }
    out
}

fn build_regex(
    search: &str,
    flags: FINDREPLACE_FLAGS,
    options: &FindOptions,
) -> Result<Regex, String> {
    let mut pattern = search.to_string();
    if (flags & FR_WHOLEWORD) != FINDREPLACE_FLAGS(0) {
        pattern = format!(r"\b(?:{})\b", pattern);
    }
    let mut prefix = String::new();
    if (flags & FR_MATCHCASE) == FINDREPLACE_FLAGS(0) {
        prefix.push_str("(?i)");
    }
    if options.dot_matches_newline {
        prefix.push_str("(?s)");
    }
    let final_pattern = format!("{prefix}{pattern}");
    Regex::new(&final_pattern).map_err(|err| err.to_string())
}

fn find_next_regex(
    hwnd: HWND,
    hwnd_edit: HWND,
    search: &str,
    flags: FINDREPLACE_FLAGS,
    wrap: bool,
    options: &FindOptions,
) -> bool {
    let language = { with_state(hwnd, |state| state.settings.language) }.unwrap_or_default();
    let regex = match build_regex(search, flags, options) {
        Ok(regex) => regex,
        Err(err) => {
            let message = i18n::tr_f(language, "find.regex_error", &[("err", &err)]);
            show_error(hwnd, language, &message);
            return false;
        }
    };
    let original_text = get_edit_text(hwnd_edit);
    if original_text.is_empty() {
        return false;
    }

    // Only normalize \r\n to \n when dot_matches_newline is enabled
    // This way, when disabled, \r\n remains two chars and . won't match newlines
    let (text, index_map) = if options.dot_matches_newline {
        normalize_line_endings_for_search(&original_text)
    } else {
        // No normalization - create identity mapping
        let map: Vec<usize> = (0..=original_text.len()).collect();
        (original_text.clone(), map)
    };

    let mut cr = CHARRANGE { cpMin: 0, cpMax: 0 };
    unsafe {
        SendMessageW(
            hwnd_edit,
            EM_EXGETSEL,
            WPARAM(0),
            LPARAM(&mut cr as *mut _ as isize),
        );
    }
    let down = (flags & FR_DOWN) != FINDREPLACE_FLAGS(0);
    let start_utf16 = if down { cr.cpMax } else { cr.cpMin };
    let start_byte_original = utf16_index_to_byte(&original_text, start_utf16);
    // Find the normalized index that corresponds to this original index
    let start_byte = if options.dot_matches_newline {
        index_map
            .iter()
            .position(|&orig| orig >= start_byte_original)
            .unwrap_or(text.len())
    } else {
        start_byte_original
    };

    let found = if down {
        regex_find_forward(&regex, &text, start_byte).or_else(|| {
            if wrap {
                regex_find_forward(&regex, &text, 0)
            } else {
                None
            }
        })
    } else {
        regex_find_backward(&regex, &text, start_byte).or_else(|| {
            if wrap {
                regex_find_backward(&regex, &text, text.len())
            } else {
                None
            }
        })
    };
    let Some((norm_start, norm_end)) = found else {
        return false;
    };

    // Map indices back to original text
    let (orig_start, orig_end) = if options.dot_matches_newline {
        (
            map_normalized_to_original(&index_map, norm_start),
            map_normalized_to_original(&index_map, norm_end),
        )
    } else {
        (norm_start, norm_end)
    };

    let mut sel = CHARRANGE {
        cpMin: byte_index_to_utf16(&original_text, orig_start),
        cpMax: byte_index_to_utf16(&original_text, orig_end),
    };
    std::mem::swap(&mut sel.cpMin, &mut sel.cpMax);
    unsafe {
        SendMessageW(
            hwnd_edit,
            EM_EXSETSEL,
            WPARAM(0),
            LPARAM(&mut sel as *mut _ as isize),
        );
        SendMessageW(hwnd_edit, EM_SCROLLCARET, WPARAM(0), LPARAM(0));
        SetFocus(hwnd_edit);
    }
    true
}

fn regex_find_forward(regex: &Regex, text: &str, start: usize) -> Option<(usize, usize)> {
    let slice = &text[start..];
    if let Some(found) = regex.find_iter(slice).flatten().next() {
        return Some((start + found.start(), start + found.end()));
    }
    None
}

fn regex_find_backward(regex: &Regex, text: &str, end: usize) -> Option<(usize, usize)> {
    let slice = &text[..end];
    let mut last = None;
    for found in regex.find_iter(slice).flatten() {
        last = Some((found.start(), found.end()));
    }
    last
}

fn replace_selection_if_match_regex(
    hwnd: HWND,
    hwnd_edit: HWND,
    search: &str,
    replace: &str,
    flags: FINDREPLACE_FLAGS,
    options: &FindOptions,
) -> bool {
    let language = { with_state(hwnd, |state| state.settings.language) }.unwrap_or_default();
    let regex = match build_regex(search, flags, options) {
        Ok(regex) => regex,
        Err(err) => {
            let message = i18n::tr_f(language, "find.regex_error", &[("err", &err)]);
            show_error(hwnd, language, &message);
            return false;
        }
    };
    let mut cr = CHARRANGE { cpMin: 0, cpMax: 0 };
    unsafe {
        SendMessageW(
            hwnd_edit,
            EM_EXGETSEL,
            WPARAM(0),
            LPARAM(&mut cr as *mut _ as isize),
        );
    }
    if cr.cpMin == cr.cpMax {
        return false;
    }
    let text = get_edit_text(hwnd_edit);
    let start = utf16_index_to_byte(&text, cr.cpMin);
    let end = utf16_index_to_byte(&text, cr.cpMax);
    let selected = &text[start..end];
    let mut iter = regex.find_iter(selected);
    let Some(Ok(found)) = iter.next() else {
        return false;
    };
    if found.start() != 0 || found.end() != selected.len() {
        return false;
    }
    let normalized = normalize_regex_replacement(replace);
    let replaced = regex.replace(selected, normalized.as_str()).to_string();
    let replace_wide = to_wide(&replaced);
    unsafe {
        SendMessageW(
            hwnd_edit,
            EM_REPLACESEL,
            WPARAM(1),
            LPARAM(replace_wide.as_ptr() as isize),
        );
    }
    true
}

fn replace_all_regex(
    hwnd: HWND,
    hwnd_edit: HWND,
    search: &str,
    replace: &str,
    flags: FINDREPLACE_FLAGS,
    options: &FindOptions,
) {
    if search.is_empty() {
        return;
    }
    let language = { with_state(hwnd, |state| state.settings.language) }.unwrap_or_default();
    let regex = match build_regex(search, flags, options) {
        Ok(regex) => regex,
        Err(err) => {
            let message = i18n::tr_f(language, "find.regex_error", &[("err", &err)]);
            show_error(hwnd, language, &message);
            return;
        }
    };
    let normalized = normalize_regex_replacement(replace);
    let mut total_count = 0usize;

    if options.replace_in_all_docs {
        let edits = {
            with_state(hwnd, |state| {
                state
                    .docs
                    .iter()
                    .map(|doc| doc.hwnd_edit)
                    .collect::<Vec<_>>()
            })
        }
        .unwrap_or_default();
        for hwnd_doc in edits {
            let text = get_edit_text(hwnd_doc);
            if text.is_empty() {
                continue;
            }
            let count = regex.find_iter(&text).count();
            if count == 0 {
                continue;
            }
            total_count += count;
            let replaced = regex.replace_all(&text, normalized.as_str()).to_string();
            replace_range_text(hwnd_doc, 0, -1, &replaced);
        }
    } else if options.replace_in_selection {
        let mut cr = CHARRANGE { cpMin: 0, cpMax: 0 };
        unsafe {
            SendMessageW(
                hwnd_edit,
                EM_EXGETSEL,
                WPARAM(0),
                LPARAM(&mut cr as *mut _ as isize),
            );
        }
        if cr.cpMin == cr.cpMax {
            return;
        }
        let text = get_edit_text(hwnd_edit);
        let start = utf16_index_to_byte(&text, cr.cpMin);
        let end = utf16_index_to_byte(&text, cr.cpMax);
        let selected = &text[start..end];
        let count = regex.find_iter(selected).count();
        if count > 0 {
            total_count = count;
            let replaced = regex.replace_all(selected, normalized.as_str()).to_string();
            replace_range_text(hwnd_edit, cr.cpMin, cr.cpMax, &replaced);
        }
    } else {
        let text = get_edit_text(hwnd_edit);
        let count = regex.find_iter(&text).count();
        if count > 0 {
            total_count = count;
            let replaced = regex.replace_all(&text, normalized.as_str()).to_string();
            replace_range_text(hwnd_edit, 0, -1, &replaced);
        }
    }

    if total_count == 0 {
        let message = to_wide(&text_not_found_message(language));
        let title = to_wide(&find_title(language));
        crate::message_box_modal(
            hwnd,
            PCWSTR(message.as_ptr()),
            PCWSTR(title.as_ptr()),
            MB_OK | MB_ICONWARNING,
        );
    } else {
        let message = replaced_count_message(language, total_count);
        show_info(hwnd, language, &message);
    }
}

fn compute_replace_patch(
    text: &str,
    search: &str,
    replace: &str,
    flags: FINDREPLACE_FLAGS,
    start_utf16: i32,
    end_utf16: i32,
) -> (usize, Option<(i32, i32, String)>) {
    if search.is_empty() {
        return (0, None);
    }
    let total_utf16 = byte_index_to_utf16(text, text.len());
    let range_start = start_utf16.clamp(0, total_utf16);
    let range_end = end_utf16.clamp(range_start, total_utf16);
    if range_start >= range_end {
        return (0, None);
    }

    let start_byte = utf16_index_to_byte(text, range_start);
    let end_byte = utf16_index_to_byte(text, range_end);
    let segment = &text[start_byte..end_byte];

    let match_case = (flags & FR_MATCHCASE) != FINDREPLACE_FLAGS(0);
    let whole_word = (flags & FR_WHOLEWORD) != FINDREPLACE_FLAGS(0);
    let (count, replaced) =
        replace_plain_text_bulk(segment, search, replace, match_case, whole_word);
    if count == 0 {
        (0, None)
    } else {
        (count, Some((range_start, range_end, replaced)))
    }
}

fn replace_plain_text_bulk(
    text: &str,
    search: &str,
    replace: &str,
    match_case: bool,
    whole_word: bool,
) -> (usize, String) {
    if search.is_empty() || text.is_empty() {
        return (0, text.to_string());
    }
    if match_case && !whole_word {
        let count = text.matches(search).count();
        if count == 0 {
            return (0, text.to_string());
        }
        return (count, text.replace(search, replace));
    }

    let escaped = escape_regex_literal(search);
    let mut pattern = if whole_word {
        format!(r"\b{}\b", escaped)
    } else {
        escaped
    };
    if !match_case {
        pattern = format!("(?i){pattern}");
    }
    let Ok(regex) = Regex::new(&pattern) else {
        return (0, text.to_string());
    };
    let count = regex.find_iter(text).count();
    if count == 0 {
        return (0, text.to_string());
    }
    let replaced = regex.replace_all(text, replace).to_string();
    (count, replaced)
}

fn escape_regex_literal(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    for ch in text.chars() {
        match ch {
            '\\' | '.' | '+' | '*' | '?' | '(' | ')' | '[' | ']' | '{' | '}' | '^' | '$' | '|' => {
                out.push('\\');
                out.push(ch);
            }
            _ => out.push(ch),
        }
    }
    out
}

fn replace_range_text(hwnd_edit: HWND, start_utf16: i32, end_utf16: i32, text: &str) {
    let mut range = CHARRANGE {
        cpMin: start_utf16,
        cpMax: end_utf16,
    };
    unsafe {
        SendMessageW(
            hwnd_edit,
            EM_EXSETSEL,
            WPARAM(0),
            LPARAM(&mut range as *mut _ as isize),
        );
    }
    let wide = to_wide(text);
    unsafe {
        SendMessageW(
            hwnd_edit,
            EM_REPLACESEL,
            WPARAM(1),
            LPARAM(wide.as_ptr() as isize),
        );
    }
}

pub fn handle_replace_all_progress(hwnd: HWND, wparam: WPARAM) {
    update_replace_progress_window(hwnd, wparam.0.min(100));
}

pub fn handle_replace_all_done(hwnd: HWND, lparam: LPARAM) {
    if lparam.0 == 0 {
        return;
    }
    let done = unsafe { Box::from_raw(lparam.0 as *mut ReplaceAllDone) };
    with_state(hwnd, |state| {
        state.replace_cancel_token = None;
        state.replace_cancel_requested = false;
    });
    close_replace_progress_window(hwnd, done.progress);
    if done.canceled {
        return;
    }
    for patch in done.patches {
        suspend_edit_redraw(patch.hwnd_edit);
        replace_range_text(
            patch.hwnd_edit,
            patch.start_utf16,
            patch.end_utf16,
            &patch.replaced,
        );
        resume_edit_redraw(patch.hwnd_edit);
    }
    if done.count == 0 {
        let message = to_wide(&text_not_found_message(done.language));
        let title = to_wide(&find_title(done.language));
        crate::message_box_modal(
            hwnd,
            PCWSTR(message.as_ptr()),
            PCWSTR(title.as_ptr()),
            MB_OK | MB_ICONWARNING,
        );
    } else {
        let message = replaced_count_message(done.language, done.count);
        show_info(hwnd, done.language, &message);
    }
}

/// Normalizes Windows line endings (\r\n) to Unix (\n) for regex searching.
/// Returns the normalized text and a mapping from normalized byte indices to original byte indices.
fn normalize_line_endings_for_search(text: &str) -> (String, Vec<usize>) {
    let mut normalized = String::with_capacity(text.len());
    let mut index_map = Vec::with_capacity(text.len() + 1);

    let mut chars = text.char_indices().peekable();
    while let Some((orig_idx, ch)) = chars.next() {
        if ch == '\r'
            && let Some(&(_, '\n')) = chars.peek()
        {
            // Skip \r, the \n will be added in next iteration
            continue;
        }
        index_map.push(orig_idx);
        normalized.push(ch);
    }
    // Map the end position
    index_map.push(text.len());

    (normalized, index_map)
}

/// Maps a byte index in normalized text back to byte index in original text
fn map_normalized_to_original(index_map: &[usize], normalized_idx: usize) -> usize {
    if normalized_idx >= index_map.len() {
        *index_map.last().unwrap_or(&0)
    } else {
        index_map[normalized_idx]
    }
}

fn utf16_index_to_byte(text: &str, target: i32) -> usize {
    if target <= 0 {
        return 0;
    }
    let target = target as usize;
    let mut utf16_count = 0usize;
    for (byte_idx, ch) in text.char_indices() {
        let units = ch.len_utf16();
        let next = utf16_count + units;
        if target <= next {
            if target == next {
                return byte_idx + ch.len_utf8();
            }
            return byte_idx;
        }
        utf16_count = next;
    }
    text.len()
}

fn byte_index_to_utf16(text: &str, byte_idx: usize) -> i32 {
    let mut utf16_count = 0usize;
    for (idx, ch) in text.char_indices() {
        if idx >= byte_idx {
            break;
        }
        utf16_count += ch.len_utf16();
    }
    utf16_count as i32
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_regex_dot_matches_space() {
        let options = FindOptions {
            use_regex: true,
            dot_matches_newline: false,
            wrap_around: false,
            match_case: false,
            whole_word: false,
            replace_in_selection: false,
            replace_in_all_docs: false,
        };
        let flags = FR_DOWN;
        let regex = build_regex("hello.world", flags, &options).unwrap();
        let text = "hello world";
        let result = regex_find_forward(&regex, text, 0);
        assert!(result.is_some(), "hello.world should match 'hello world'");
        let (start, end) = result.unwrap();
        assert_eq!(&text[start..end], "hello world");
    }

    #[test]
    fn test_regex_dot_matches_newline_disabled() {
        let options = FindOptions {
            use_regex: true,
            dot_matches_newline: false,
            wrap_around: false,
            match_case: false,
            whole_word: false,
            replace_in_selection: false,
            replace_in_all_docs: false,
        };
        let flags = FR_DOWN;
        let regex = build_regex("hello.world", flags, &options).unwrap();
        let text = "hello\nworld";
        let result = regex_find_forward(&regex, text, 0);
        assert!(
            result.is_none(),
            "hello.world should NOT match 'hello\\nworld' without (?s)"
        );
    }

    #[test]
    fn test_regex_dot_matches_newline_enabled() {
        let options = FindOptions {
            use_regex: true,
            dot_matches_newline: true,
            wrap_around: false,
            match_case: false,
            whole_word: false,
            replace_in_selection: false,
            replace_in_all_docs: false,
        };
        let flags = FR_DOWN;
        let regex = build_regex("hello.world", flags, &options).unwrap();
        let text = "hello\nworld";
        let result = regex_find_forward(&regex, text, 0);
        assert!(
            result.is_some(),
            "hello.world should match 'hello\\nworld' with (?s)"
        );
    }

    #[test]
    fn test_regex_simple_space_verbose() {
        // Exactly what the user is doing
        let search = "hello.world";
        let text = "hello world";

        let options = FindOptions {
            use_regex: true,
            dot_matches_newline: false,
            wrap_around: false,
            match_case: false,
            whole_word: false,
            replace_in_selection: false,
            replace_in_all_docs: false,
        };
        let flags = FR_DOWN;

        println!("Search pattern: '{}'", search);
        println!("Text: '{}'", text);
        println!("Text bytes: {:?}", text.as_bytes());
        println!("Text len: {}", text.len());

        let regex = build_regex(search, flags, &options).unwrap();
        println!("Built regex pattern: {:?}", regex.as_str());

        // Direct regex test
        let direct_match = regex.find(text);
        println!("Direct regex.find result: {:?}", direct_match);

        // Through our function
        let result = regex_find_forward(&regex, text, 0);
        println!("regex_find_forward result: {:?}", result);

        assert!(result.is_some(), "hello.world MUST match 'hello world'");
    }

    #[test]
    fn test_regex_with_crlf_after_normalization() {
        // Test that normalization converts \r\n to \n so hello.world matches
        let options = FindOptions {
            use_regex: true,
            dot_matches_newline: true,
            wrap_around: false,
            match_case: false,
            whole_word: false,
            replace_in_selection: false,
            replace_in_all_docs: false,
        };
        let flags = FR_DOWN;
        let regex = build_regex("hello.world", flags, &options).unwrap();

        // Original text with Windows line endings
        let original_text = "hello\r\nworld";

        // After normalization, \r\n becomes \n
        let (normalized, index_map) = normalize_line_endings_for_search(original_text);
        assert_eq!(normalized, "hello\nworld");

        // Now the search should find it
        let result = regex_find_forward(&regex, &normalized, 0);
        assert!(
            result.is_some(),
            "hello.world should match 'hello\\r\\nworld' after normalization"
        );

        // Verify index mapping works correctly
        let (norm_start, norm_end) = result.unwrap();
        let orig_start = map_normalized_to_original(&index_map, norm_start);
        let orig_end = map_normalized_to_original(&index_map, norm_end);

        // The match in normalized text is "hello\nworld" (0..11)
        // In original text, it should map to "hello\r\nworld" (0..12)
        assert_eq!(orig_start, 0);
        assert_eq!(orig_end, 12); // 12 because original has \r\n (2 chars) instead of \n (1 char)
    }

    #[test]
    fn test_normalize_line_endings() {
        let (normalized, index_map) = normalize_line_endings_for_search("a\r\nb\r\nc");
        assert_eq!(normalized, "a\nb\nc");
        // index_map should map: 0->0 (a), 1->1 (\n, skipping \r at 1), 2->3 (b), 3->4 (\n), 4->6 (c), 5->7 (end)
        assert_eq!(index_map[0], 0); // 'a'
        assert_eq!(index_map[1], 2); // '\n' (original position after \r)
        assert_eq!(index_map[2], 3); // 'b'
        assert_eq!(index_map[3], 5); // '\n'
        assert_eq!(index_map[4], 6); // 'c'
        assert_eq!(index_map[5], 7); // end
    }
}
